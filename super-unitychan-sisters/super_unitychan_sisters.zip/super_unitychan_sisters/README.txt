==============================================================================
作品名　：Super Unitychan Sisters1
著作者　：DAT_YoketoruTeam
開発環境：Windows10 + Unity2019.4.11 + Visual Studio 2019
開発期間：2021/10/13-2021/12/15(2ヶ月)
開発人数：4人
==============================================================================

◆概要
敵や障害物を避けてゴールを目指すプラットフォームゲーム。


◆実行手順
1. 公開ページからZIPファイルをダウンロード
2. ダウンロードしたZIPファイルを、任意のフォルダーに展開
3. 展開したフォルダー内の SURER UNITYCHAN SISTERS 1.exe をダブルクリックして起動


◆操作とルール
- [A][D] / 左右キー・・プレイヤー移動
- [SPACE]キー・・・・・ジャンプ
- [J]キー・・・・・・・攻撃（ステージ３のみ）
- 敵や障害物にぶつかるとミス
- 落下してもミス。ただし、下にマップが続くこともあり
- ゴールに着いたらステージクリア！ 


◆組み込みアセットのライセンス
以下のアセットをプロジェクトに組み込んでいます。
-Unity Asset Store
	Meshtint Studio. Meshtint Free Tile Map Mega Toon Series
	AurynSky. Winter Forest - Low Poly Toon Battle Arena / Tower Defense Pack
	WAND AND CIRCLES. HYPEPOLY - Isometric Tiles Standart Lite
	Sergio Sotomayor. Free Low Poly Toon Nature
	Andrey Graphics. Low Poly Pack
	Ebru Dogan. LowPoly Water
	Polytope Studio. Lowpoly Environment - Nature Pack Free
	Comeback. Stylized Rocks with Magic Rune
	Dungeon Mason. RPG Monster Duo PBR Polyart
	Sabri Ayes. Tower Defence - Cannon
	Synty Studios. Simple Sky - Cartoon assets
	Render Knight. Fantasy Skybox FREE
	Jean Moreno (JMO). Cartoon FX Free
	Steven Craeynent. Frost Effect
-フォント
	Caffeen Fonts. Chlorinap
-音源
	魔王魂
	OpenGameArt.org
	効果音ラボ
	効果音工房
	ポケットサウンド

-©Unity Technologies Japan/UCL


[EOF]
