==============================================================================
作品名　：Barrage
著作者　：danmaku Team
開発環境：Windows10 + Unity2019.4.11 + Visual Studio 2019
開発期間：2021/10/13-2021/11/4(1ヶ月)
開発人数：6人
==============================================================================

◆概要
10秒以内に敵や弾に当たらないように敵を全て倒しきるゲームです。


◆実行手順
1. 公開ページからZIPファイルをダウンロード
2. ダウンロードしたZIPファイルを、任意のフォルダーに展開
3. 展開したフォルダー内の Barrage.exe をダブルクリックして起動


◆操作とルール
- WASD・矢印キーで操作
- 10秒以内に敵を全て倒してください
- 敵か弾にぶつかるか10秒経過でゲームオーバー
- タイトル画面で[ESC]キーで終了


◆組み込みアセットのライセンス
以下のアセットをプロジェクトに組み込んでいます。

タイトルbgm
https://pocket-se.info/archives/1840/

戦闘bgm
https://pocket-se.info/archives/895/

切り替え音
https://soundeffect-lab.info/sound/battle/battle2.html
ボタンシステム音　決定、ボタン押下７

射撃音
https://soundeffect-lab.info/sound/battle/battle2.html
戦闘２　ショット

敵攻撃音
https://pocket-se.info/archives/746/

クリア音
https://pocket-se.info/archives/1810/

ゲームオーバー音
https://pocket-se.info/archives/1751/

背景１
https://www.ac-illust.com/main/detail.php?id=2632267&word=%E3%80%90%E8%83%8C%E6%99%AF%E3%80%91%E3%83%AA%E3%82%A2%E3%83%AB%E3%81%AA%E6%B0%B4%E9%9D%A2_%E6%B5%B7%E9%9D%A2_%E6%B9%96%E9%9D%A2&searchId=773129424

背景２
https://www.photo-ac.com/main/detail/2985803


[EOF]